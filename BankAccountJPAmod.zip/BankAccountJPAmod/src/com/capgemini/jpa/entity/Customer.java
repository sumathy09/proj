package com.capgemini.jpa.entity;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Customer {
	@Id
	private int accNo;
	private String name;
	private String phoneNo;
	private String address;
	private String aathar;
	
	
	private String transaction;
	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
    private double balance;
	 
    @OneToMany(mappedBy="cus",cascade=CascadeType.ALL)
	private List<Transaction> customer = new ArrayList<Transaction>();
	 
	 

	public List<Transaction> getCustomer() {
		return customer;
	}

	public void setCustomer(List<Transaction> customer) {
		this.customer = customer;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAathar() {
		return aathar;
	}

	public void setAathar(String aathar) {
		this.aathar = aathar;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo2) {
		this.accNo = accNo2;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	

	@Override
	public String toString() {
		return "Customer [name=" + name + ", phoneNo=" + phoneNo + ", address="
				+ address + ", aathar=" + aathar + ", balance=" + balance + "]"
				+ "\n";
	}

	public String CustomerTransaction(Transaction trans)
	{
	    if(this.transaction==null)
	        this.transaction="";
	    return this.transaction=this.transaction;
	}
	

}



 