package com.capgemini.jpa.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.jpa.dao.BankImplementationDao;
import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.exception.CustomerException;

 
public class BankImplementationDaoTest {

	@Test
	public void testCreateAccount() throws CustomerException {
		BankImplementationDao dao=new BankImplementationDao();
		Customer cust=new Customer();
			cust.setAccNo(1000);
			cust.setAathar("987676787575");
			cust.setAddress("chennai");
			cust.setBalance(200);
			cust.setName("Sumathy");
			cust.setPhoneNo("9857676758");
			//System.out.println(cust);
			Customer cu=dao.createAccount(cust);
			assertEquals(cust, cu);
		
	}

	@Test
	public void testShowBalance() {
		 
	}

	@Test
	public void testDeposit() {
		 
	}

	@Test
	public void testWithdraw() {
		 
	}

	@Test
	public void testFundTransfer() {
		 
	}

	@Test
	public void testValidAccount() {
		 
	}

}
