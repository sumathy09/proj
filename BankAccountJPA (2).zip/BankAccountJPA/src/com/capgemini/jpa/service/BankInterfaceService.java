package com.capgemini.jpa.service;

//import com.capgemini.jpa.dao.CustomerException;
import java.util.List;

import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.CustomerException;

public interface BankInterfaceService {
	  Customer createAccount(Customer cust)throws CustomerException;
	    double showBalance(int accNo)throws CustomerException;
	    double deposit(int accNo,double deposit)throws CustomerException;
	    double withdraw(int accNo,double withdraw)throws CustomerException;
	    double fundTransfer(int ida,int idb,double transfer)throws CustomerException;
	    List<Transaction> printTransactions(int id)throws CustomerException;
		boolean isValidName(String name);
		boolean isValidPhone(String phoneNo);
		boolean isValidAathar(String aathar);
		int validAccount(int id1)throws CustomerException;
}
