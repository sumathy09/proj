package com.capgemini.jpa.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.jpa.dao.BankImplementationDao;
import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.exception.CustomerException;

 
public class BankImplementationDaoTest {

	@Test
	public void testCreateAccount() throws CustomerException {
		BankImplementationDao dao=new BankImplementationDao();
		Customer cust=new Customer();
			cust.setAccNo(1000);
			cust.setAathar("987676787575");
			cust.setAddress("chennai");
			cust.setBalance(200);
			cust.setName("Sumathy");
			cust.setPhoneNo("9857676758");
			//System.out.println(cust);
			Customer cu=dao.createAccount(cust);
			assertEquals(cust, cu);
		
	}

	@Test
	public void testShowBalance() {
		BankImplementationDao dao=new BankImplementationDao();
		Customer cust=new Customer();
		double bal=dao.showBalance(1000);
		assertEquals(200,bal);
	}

	@Test
	public void testDeposit() {
		BankImplementationDao dao=new BankImplementationDao();
		Customer cust=new Customer(); 
		double b=dao.deposit(1000,100);
		assertEquals(300,b);
		
	}

	@Test
	public void testWithdraw() {
		BankImplementationDao dao=new BankImplementationDao();
		Customer cust=new Customer(); 
		double b=dao.withdraw(1000,50);
		assertEquals(250,b);
	}

	@Test
	public void testFundTransfer() {
		BankImplementationDao dao=new BankImplementationDao();
		Customer cust=new Customer();	 
	}

	@Test
	public void testValidAccount() {
		BankImplementationDao dao=new BankImplementationDao();
		Customer cust=new Customer(); 
		int a=dao.validAccount(1000);
		assertEquals(1000,a);
	}

}